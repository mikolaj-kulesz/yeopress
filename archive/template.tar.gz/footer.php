		</div>
		<footer id="page-footer">
			<p class="footer-copyright">Copyright &copy; <?= date('Y') ?> <?php bloginfo('name') ?></p>
		</footer>
		<?php wp_footer() ?>
	</body>
</html>
