<aside id="page-sidebar">
	<ul>
		<?php if ( ! dynamic_sidebar( 'main-sidebar' ) ) : ?>

		<?php endif; ?>
	</ul>
</aside>
